/** Automatically generated file. DO NOT MODIFY */
package com.example.ems_apiezo;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}