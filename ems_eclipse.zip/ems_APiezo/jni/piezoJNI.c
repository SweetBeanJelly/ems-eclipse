
#include <jni.h>
#include <unistd.h>
#include <fcntl.h>
#include <assert.h>

static int fd;

JNIEXPORT void JNICALL Java_com_example_piezojni_PiezoJNI_open
  (JNIEnv * env, jobject obj){
	fd = open("/dev/fpga_piezo", O_WRONLY);
		assert(fd != -1);
}

JNIEXPORT void JNICALL Java_com_example_piezojni_PiezoJNI_write
  (JNIEnv * env, jobject obj, jchar data){
	write(fd, &data, 1);
}

JNIEXPORT void JNICALL Java_com_example_piezojni_PiezoJNI_close
  (JNIEnv * env, jobject obj){
	close(fd);
}

