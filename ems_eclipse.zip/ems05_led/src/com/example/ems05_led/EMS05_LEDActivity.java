package com.example.ems05_led;

import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;
import android.view.View;
import android.widget.CheckBox;
import com.example.ledjni.LedJNI;

public class EMS05_LEDActivity extends Activity {
	
	private int ledIds[] = {
			R.id.led8, R.id.led7, R.id.led6, R.id.led5,
			R.id.led4, R.id.led3, R.id.led2, R.id.led1
	};

	private char ledData = (char)0;
	private LedJNI ledJNI;
	private CheckBox [] leds = new CheckBox[8];

	@Override
	protected void onCreate(Bundle savedInstanceState) { // ���� �� ��
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		
		ledJNI = new LedJNI();
		ledJNI.on(ledData);
		
		for (int i = 0; i < 8; ++i) {
			leds[i] = (CheckBox)this.findViewById(ledIds[i]);
			leds[i].setOnClickListener(new ClickListener());
		}
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.ems05__led, menu);
		return true;
	}
	
	class ClickListener implements CheckBox.OnClickListener {
		@Override
		public void onClick(View arg0) {
			for (int i = 0; i < 8; ++i) {
				if (leds[i].isChecked())
					ledData |= (0x80 >> i);
				else
					ledData &= ~(0x80 >> i); // ���� -> mask ��Ŵ
		
				ledJNI.on(ledData);
			}
		}
	}
		
}
