package com.example.ems05_adipsw;

import com.example.dipswjni.DipswJNI;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.app.Activity;
import android.view.Menu;
import android.widget.CheckBox;

public class ADipswActivity extends Activity {
	
	private final static int [] leftIds = {
	R.id.dipsw11, R.id.dipsw12, R.id.dipsw13, R.id.dipsw14,
	R.id.dipsw15, R.id.dipsw16, R.id.dipsw17, R.id.dipsw18
	};
	
	private final static int [] rightIds = {
	R.id.dipsw21, R.id.dipsw22, R.id.dipsw23, R.id.dipsw24,
	R.id.dipsw25, R.id.dipsw26, R.id.dipsw27, R.id.dipsw28
	};
	
	private CheckBox [] leftDipSwitches = new CheckBox[8];
	private CheckBox [] rightDipSwitched = new CheckBox[8];
	
	private DipswJNI dipswJNI = new DipswJNI();
	private EventHandler eventHandler;
	private MyThread thread;
	private boolean start;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		
		eventHandler = new EventHandler();

		for (int i = 0; i < 8; ++i) {
		this.leftDipSwitches[i] = (CheckBox)this.findViewById(this.leftIds[i]);
		this.rightDipSwitched[i] = (CheckBox)this.findViewById(this.rightIds[i]);
		}
	}
	
	@Override
	public void onResume() {
	dipswJNI.open();

	start = true;
	thread = new MyThread();
	thread.start();
	
	super.onResume();
	}
	@Override
	public void onPause() {
	dipswJNI.close();
	start = false;
	super.onPause();
	}
	
	public class EventHandler extends Handler {
	EventHandler() {}
	
	public void handleMessage(Message msg) {
		short value = dipswJNI.get();
		for (int i = 0; i < 8; ++i) {
			leftDipSwitches[i].setChecked( (value & (1 << i)) != 0);
			rightDipSwitched[i].setChecked( (value & ((1 << 7) << i)) != 0);
		 }
		}
	}
	
	class MyThread extends Thread {
		public void run() {
			while (start)
			{
			Message msg1 = eventHandler.obtainMessage();
			eventHandler.sendMessage(msg1);
			
			try {
				Thread.sleep(500);
				} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				}
			} // while(start)
		}
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.adipsw, menu);
		return true;
	}

}
