package com.example.dipswjni;

public class DipswJNI {
	static {
		System.loadLibrary("dipswJNI");
	}
		
	public native void open();
	public native void close();
	public native short get();
}
