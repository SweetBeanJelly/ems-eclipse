
#include <unistd.h>
#include <fcntl.h>
#include <assert.h>
#include <jni.h>

static int fd;

JNIEXPORT void JNICALL Java_com_example_dipswjni_DipswJNI_open
  (JNIEnv * env, jobject obj){
	fd = open("/dev/fpga_dipsw", O_RDONLY);
	assert(fd != 0);
}

JNIEXPORT void JNICALL Java_com_example_dipswjni_DipswJNI_close
  (JNIEnv * env, jobject obj){
	close(fd);
}

JNIEXPORT jshort JNICALL Java_com_example_dipswjni_DipswJNI_get
  (JNIEnv * env, jobject obj){
	short int re;
	read(fd, &re, 2);

	return re;
}

