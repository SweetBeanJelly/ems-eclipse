#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <fcntl.h>
#include <assert.h>
#include "font.h"

int main(int argc, char * argv[]) {

	//
	int fd;
	unsigned char nullValue = 0x00;
	unsigned char check;
	fd = open("/dev/ems_piezo", O_WRONLY);
	assert(fd != 0);
	//

	int dev, i, j, offset = 20, ch;
	char result[600], tmp[2], input[100];

	dev = open("/dev/ems_dotmatrix", O_WRONLY);
	if (dev != -1) {
		printf("Input Nunber : ");

		scanf("%s", input);

		//
		switch ((char)input[0]) {
		case '1':
			check=0x11; break;
		case '2':
			check=0x12; break;
		case '3':
			check=0x13; break;
		case '4':
			check=0x14; break;
		case '5':
			check=0x15; break;
		case '6':
			check=0x16; break;
		case '7':
			check=0x17; break;
		case '8':
			check=0x21; break;
		}

		write(fd, &check, 1);
		usleep(200000);
		write(fd, &nullValue, 1);
		//

		for (j = 0; j < 20; j++)
		result[j] = '0';
		for (i = 0; i < 1; i++) {
			ch = input[i];

			ch -= 0x20;

			for (j = 0; j < 5; j++) {
				sprintf(tmp, "%x%x", font[ch][j] / 16, font[ch][j] % 16);
				result[offset++] = tmp[0];
				result[offset++] = tmp[1];
				}
			result[offset++] = '0';
			result[offset++] = '0';
		}
		for (j = 0; j < 20; j++)
		result[offset++] = '0';

		for (i = 0; i < (offset - 18) / 2; i++) {
			for (j = 0; j < 20; j++) {
				write(dev, &result[2 * i], 20);
			}
		}
	} else {
		printf("Device Open ERROR!\n");
		exit(1);
		}

	close(dev);
	printf("Program Exit !!\n");

	return 0;

}
