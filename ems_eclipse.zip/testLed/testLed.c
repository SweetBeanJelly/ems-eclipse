#include <unistd.h>
#include <fcntl.h>
#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
#include <time.h>
#include <math.h>
void delay(clock_t n)
{	clock_t start = clock();
	while (clock() - start < n)
		;}

int main(void) {
	int fd;
	int i;
	unsigned char ch;
	fd = open("/dev/fpga_led", O_WRONLY);
	assert(fd != -1);


// infinite loop
for(;;){
	ch = (unsigned char) 255;//��ü �� ���ѱ�
	 write(fd, &ch, 1);
	 delay(300000);

	 for(i=0; i<16;i++){
 unsigned char ch;
 int a[16] = { 255,1,255,2,255,4,255,8,255,16,255,32,255,64,255,128};

 //fprintf(stdout, "Input LED value [0-255] : ");
 //fscanf(stdin, "%d", &value);

 ch = (unsigned char) a[i];
 write(fd, &ch, 1);
 delay(100000);
 }

}
 close(fd);
 return 0;
 }
