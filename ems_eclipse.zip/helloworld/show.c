/*
 * show.c
 *
 *  Created on: 2018. 3. 16.
 *      Author: Pknu
 */
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>

void show() {
	printf("Hello WORLD");
}
