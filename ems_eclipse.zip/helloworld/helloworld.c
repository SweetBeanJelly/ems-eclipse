#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include "show.h"

int main(int argc, char * argv[]) {
	show();
	exit(0);
}
