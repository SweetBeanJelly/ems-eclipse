/** Automatically generated file. DO NOT MODIFY */
package com.example.ems05clienttest;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}