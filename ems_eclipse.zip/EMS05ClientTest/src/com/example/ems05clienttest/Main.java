package com.example.ems05clienttest;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import android.os.Bundle;
import android.app.Activity;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class Main extends Activity {
	private Socket sock;
	BufferedReader sock_in;
	PrintWriter sock_out;
	
	EditText input;
	Button button;
	TextView output;
	String data;
	
	final String serverIP = "192.168.0.18"; // server�� IP �ּ� // 210.125.126.207
	final int serverPort = 5525; // server�� port no.
	Boolean finished = false;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		input = (EditText) findViewById(R.id.input);
		button = (Button) findViewById(R.id.button);
		output = (TextView) findViewById(R.id.output);
		
		output.setText("Server IP = " + serverIP);
		button.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
			String data = input.getText().toString();
			sock_out.println(data);
			}
		});
		Thread worker = new Thread() {
			public void run() {
				try {
					Log.d("NETWORK", "9999999");
					output.setText(serverIP);
					sock = new Socket(serverIP, serverPort);
					sock_out = new PrintWriter(sock.getOutputStream(), true);
					sock_in = new BufferedReader(new
					InputStreamReader(sock.getInputStream()));
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}; // new Thread()
		worker.start();
	}


	@Override
	protected void onStop() {
		super.onStop();
		try {
			sock.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

}
