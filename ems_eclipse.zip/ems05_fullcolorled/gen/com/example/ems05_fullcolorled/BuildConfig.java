/** Automatically generated file. DO NOT MODIFY */
package com.example.ems05_fullcolorled;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}