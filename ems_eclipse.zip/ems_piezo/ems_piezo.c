#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/init.h>
#include <asm/uaccess.h>
#include <asm/io.h>
#include <linux/ioport.h>
#include <linux/fs.h>
#include <linux/miscdevice.h>
#include <linux/mutex.h>

#define PIEZO_ADDRESS 0x05000050
#define PIEZO_ADDRESS_RANGE 0x1000
#define DEVICE_NAME "ems_piezo"

static unsigned long int *piezo_ioremap;
static int piezo_usage = 0;
	
static int ems_piezo_open(struct inode * inode, struct file * file){
	
	if (piezo_usage == 1) return -EBUSY;
	piezo_ioremap = ioremap(PIEZO_ADDRESS, PIEZO_ADDRESS_RANGE);
	if ( check_mem_region( (unsigned long int) piezo_ioremap, PIEZO_ADDRESS_RANGE) /* != 0 */) {
	printk(KERN_WARNING "Can't get IO Region 0x%x\n", (unsigned int) piezo_ioremap);
	return -1; }
	request_mem_region( (unsigned long int) piezo_ioremap, PIEZO_ADDRESS_RANGE, DEVICE_NAME);
	piezo_usage = 1;

	return 0;
}

static int ems_piezo_release(struct inode * inode, struct file * file){
	release_mem_region( (unsigned long int) piezo_ioremap, PIEZO_ADDRESS_RANGE);
	iounmap(piezo_ioremap);
	piezo_usage = 0;
	
	return 0;
}

//static ssize_t ems_piezo_read(struct file * file, char * buf, size_t length, loff_t * ofs){
//	printk("ems_piezo_read, \n");
//
//	return 0;
//}

static ssize_t ems_piezo_write(struct file * file, const char * buf, size_t length, loff_t * ofs){
	unsigned char c;
	get_user(c, buf);
	*(unsigned short int *)piezo_ioremap = c;
	
	return length;
}

//static DEFINE_MUTEX(ems_piezo_mutex);
//static long ems_piezo_ioctl(struct file * file, unsigned int cmd, unsigned long arg){
//	printk("ems_piezo_ioctl, \n");
//
//	switch(cmd){
//		default:
//			mutex_unlock(&ems_piezo_mutex);
//			return ENOTTY;
//	}
//
//	mutex_unlock(&ems_piezo_mutex);
//	return 0;
//}

static struct file_operations ems_piezo_fops = {
	.owner = THIS_MODULE,
	.open = ems_piezo_open,
	.release = ems_piezo_release,
//	.read = ems_piezo_read,
	.write = ems_piezo_write,
//	.unlocked_ioctl = ems_piezo_ioctl,
};

static struct miscdevice ems_piezo_driver = {
	.minor = MISC_DYNAMIC_MINOR,
	.name = "ems_piezo",
	.fops = &ems_piezo_fops,
};

static int ems_piezo_init(void){
	printk("ems_piezo_init, \n");
	
	return misc_register(&ems_piezo_driver);
}

static void ems_piezo_exit(void){
	printk("ems_piezo_exit, \n");

	misc_deregister(&ems_piezo_driver);
	
}

module_init(ems_piezo_init);
module_exit(ems_piezo_exit);

MODULE_AUTHOR("JM");
MODULE_DESCRIPTION("Description of the ems_piezo to put it here.");
MODULE_LICENSE("Dual BSD/GPL");
