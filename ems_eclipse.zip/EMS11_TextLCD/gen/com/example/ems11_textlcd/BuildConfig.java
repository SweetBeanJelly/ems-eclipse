/** Automatically generated file. DO NOT MODIFY */
package com.example.ems11_textlcd;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}