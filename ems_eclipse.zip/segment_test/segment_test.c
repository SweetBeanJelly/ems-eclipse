#include <unistd.h>
#include <assert.h>
#include <stdio.h>
#include <fcntl.h>

int main(int argc, char * argv[]) {

	int i,j;

	int fd;
	char num[7];

	fd = open("/dev/ems_segment", O_WRONLY);

	sprintf(num,"%06s",argv[1]);
	for(;;) {
		write(fd,num,6);
	}

	close(fd);
	return 0;
}
