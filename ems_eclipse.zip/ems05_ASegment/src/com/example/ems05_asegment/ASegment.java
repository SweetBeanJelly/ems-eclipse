package com.example.ems05_asegment;

import com.example.segmentjni.*;

import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class ASegment extends Activity implements Runnable {

	private SegmentJNI segmentJNI = new SegmentJNI();
	private Thread thread = new Thread(this);
	private int count;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		final EditText digit = (EditText) findViewById(R.id.digit);
		final Button inputButton = (Button) findViewById(R.id.start);

		inputButton.setOnClickListener(new Button.OnClickListener() {
			@Override
			public void onClick(View arg0) {
				count = Integer.parseInt(digit.getText().toString());

				if (count > 1000000) {
					Toast.makeText(ASegment.this, " < 1000000",
							Toast.LENGTH_SHORT).show();
					return;
				}
				thread.start();
			}
		});

	}
	
	// �ٸ� ���α׷�������
	@Override
	protected void onResume() {
		segmentJNI.open();
		super.onResume();
	}
	@Override
	protected void onPause() {
		segmentJNI.close();
		super.onPause();
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.asegment, menu);
		return true;
	}

	// thread start �ϱ� ���� �� �ʿ�
	@Override
	public void run() {
		for (int i = count - 1; i >= 0; --i)
			segmentJNI.print(i);
		try {
			Thread.sleep(100);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
