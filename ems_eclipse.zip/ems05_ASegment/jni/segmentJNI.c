#include <unistd.h>
#include <fcntl.h>
#include <stdio.h>
#include <assert.h>
#include <jni.h>

static int fd;

JNIEXPORT void JNICALL Java_com_example_segmentjni_SegmentJNI_open
(JNIEnv * env, jobject obj){
fd = open("/dev/ems_segment", O_WRONLY);
assert(fd != -1);
}

JNIEXPORT void JNICALL Java_com_example_segmentjni_SegmentJNI_print
(JNIEnv * env, jobject obj, jint num){
char buf[7];
sprintf(buf, "%06d", num);
printf(stdout, "num: %s\n", num);
write(fd, buf, 6);
}

JNIEXPORT void JNICALL Java_com_example_segmentjni_SegmentJNI_close
(JNIEnv * env, jobject obj){
close(fd);
}
