#include <unistd.h>
#include <fcntl.h>
#include <assert.h>
#include <stdio.h>

int main(int argc, char * argv[]) {
	char num[7];

	int fd;
	fd = open("/dev/ems_dipsw", O_RDONLY);
	assert(fd != 0);

	 for (;;) {
		unsigned short int value;

		read(fd, &value, 2);
		sprintf(num,"%06s",value);
		fprintf(stdout, "value : 0x%04x\n", value);
		write(fd,num,6);
		sleep(1); }
	close(fd);
	return 0;
}
