#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/init.h>
#include <mach/hardware.h>
#include <asm/uaccess.h>
#include <asm/ioctl.h>
#include <asm/io.h>
#include <linux/types.h>
#include <linux/ioport.h>
#include <linux/fs.h>
#include <linux/miscdevice.h>
#include <linux/mutex.h>

#define DRIVER_AUTHOR "PKNU Design"
#define DRIVER_DESC "KEYPAD program"

#define KEYPAD_NAME "ems_keypad"
#define KEYPAD_PHY_ADDR 0x05000000
#define KEYPAD_ADDR_RANGE 0x1000

static unsigned long keypad_ioremap;
static unsigned char *keypad_row_addr,*keypad_col_addr;
static unsigned short *keypad_check_addr;

char keypad_fpga_keycode[16] = {
		1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16
};
	
static int ems_keypad_open(struct inode * inode, struct file * file){
	printk("ems_keypad_open, \n");
	keypad_ioremap=(unsigned long)ioremap(KEYPAD_PHY_ADDR,KEYPAD_ADDR_RANGE);
	if(!check_mem_region(keypad_ioremap, KEYPAD_ADDR_RANGE)) {
		request_mem_region(keypad_ioremap, KEYPAD_ADDR_RANGE, KEYPAD_NAME);
	} else {
		 printk("EMS KEYPAD Memory Alloc Faild!\n");
		 return -1;
	}
	keypad_col_addr = (unsigned char *)(keypad_ioremap+0x70);
	keypad_row_addr = (unsigned char *)(keypad_ioremap+0x72);
	return 0;
}

static int ems_keypad_release(struct inode * inode, struct file * file){
	printk("ems_keypad_release, \n");
	iounmap((unsigned long*)keypad_ioremap);
	release_region(keypad_ioremap, KEYPAD_ADDR_RANGE);
	return 0;
}

static ssize_t ems_keypad_read(struct file * file, char * buf, size_t length, loff_t * ofs){
	printk("ems_keypad_read, \n");
	int j=1,k,i,ret;
	unsigned char funtion_key = 0;
	unsigned short value = 0;
	unsigned char tmp[4] = {0x01, 0x02, 0x04, 0x08};
	char send_buf[20] = {0};
	 for(i=0;i<4;i++) {
		 *keypad_row_addr = tmp[i];
		 value = *keypad_col_addr & 0x0f;
		 if(value > 0) {
			 for(k=0;k<4;k++) {
				 if(value == tmp[k]) {
					 value = j+(i*4);
					 funtion_key = keypad_fpga_keycode[value-1];
					 if(value != 0x00) goto stop_poll;
				 }
				 j++;
			 }
		 }
	 }
	 stop_poll:
		 if(value > 0) {
//			 sprintf(send_buf,"%d pressed",value);
			 sprintf(send_buf,"%d",value);
		 } else {
//			 sprintf(send_buf,"pressed nothing");
			 *keypad_row_addr = 0x00;
		 }
		 ret = copy_to_user(buf,send_buf,strlen(send_buf));
		 return 0;
}

//static ssize_t ems_keypad_write(struct file * file, const char * buf, size_t length, loff_t * ofs){
//	printk("ems_keypad_write, \n");
//
//	return 0;
//}
//
//static DEFINE_MUTEX(ems_keypad_mutex);
//static long ems_keypad_ioctl(struct file * file, unsigned int cmd, unsigned long arg){
//	printk("ems_keypad_ioctl, \n");
//
//	switch(cmd){
//		default:
//			mutex_unlock(&ems_keypad_mutex);
//			return ENOTTY;
//	}
//
//	mutex_unlock(&ems_keypad_mutex);
//	return 0;
//}

static struct file_operations ems_keypad_fops = {
	.owner = THIS_MODULE,
	.open = ems_keypad_open,
	.release = ems_keypad_release,
	.read = ems_keypad_read,
//	.write = ems_keypad_write,
//	.unlocked_ioctl = ems_keypad_ioctl,
};

static struct miscdevice ems_keypad_driver = {
	.minor = MISC_DYNAMIC_MINOR,
	.name = "ems_keypad",
	.fops = &ems_keypad_fops,
};

static int ems_keypad_init(void){
	printk("ems_keypad_init, \n");
	
	return misc_register(&ems_keypad_driver);
}

static void ems_keypad_exit(void){
	printk("ems_keypad_exit, \n");

	misc_deregister(&ems_keypad_driver);
	
}

module_init(ems_keypad_init);
module_exit(ems_keypad_exit);

MODULE_AUTHOR("JM");
MODULE_DESCRIPTION("Description of the ems_keypad to put it here.");
MODULE_LICENSE("Dual BSD/GPL");
