#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>

int main(int argc, char * argv[]) {
	int arr[15]={50,8,16,22,41,61,10,4,38,29,71,5,12,67,3};
	int i;

	sort(arr,0,15-1);

	for(i=0;i<15;i++){
		printf("%d\t",arr[i]);
	}
}

void sort(int num[],int start,int end) {
	int mid=(start+end)/2; //�߰���
	if (start<end) {
	 sort(num,start,mid);
	 sort(num,mid+1,end);
	 merge(num,start,mid,end);
	}
}

void merge(int num[],int start,int mid,int end) {
	int a,b,c,d,e;
	int arr[15]; //�ӽù迭
	a = start;
	b = mid+1;
	c = start;
	while(a<=mid && b<=end)
	{
		arr[c++]=(num[a]>num[b])?num[b++]:num[a++];
	}
	d=(a>mid)?b:a;
	e=(a>mid)?end:mid;
	for(;d<=e;d++) arr[c++]=num[d];
	for(d=start;d<=end;d++) num[d]=arr[d];
}
