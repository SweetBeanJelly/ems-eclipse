#include <unistd.h>


#include <stdlib.h>


#include <stdio.h>





double factorial(int n) {





double tmp=1;


int i;





for(i=1;i<=n;i++) {


tmp *= i;


}





return tmp;





}





double calculate(double n, int i) {


return pow(n,i*2) / factorial(i*2);


}








double serise(double n) {





double tmp=0;


int i;





for(i=0;i<5;i++) {


tmp += calculate(n,i);


}





return tmp;





}








void main(void){





double n;


scanf("%lf", &n);


printf("y = %lf\n", serise(n));


}
