package com.example.ems05_atextlcdtest;

import com.example.ems05_atextlcdtest.R;
import com.example.textlcdjni.TextLcdJNI;

import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends Activity {
	
	private TextLcdJNI textLcdJNI = new TextLcdJNI();

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		
		final EditText edit1 = (EditText)findViewById(R.id.edit1);
		final EditText edit2 = (EditText)findViewById(R.id.edit2);
		final Button writeButton = (Button)findViewById(R.id.btn1);
		final Button clearButton = (Button)findViewById(R.id.btn2);

		writeButton.setOnClickListener(new Button.OnClickListener() {
			@Override
			public void onClick(View arg0) {
				final String str1 = edit1.getText().toString();
				final String str2 = edit2.getText().toString();
				textLcdJNI.clear();
				textLcdJNI.print1Line(str1);
				textLcdJNI.print2Line(str2);
			}
		});

		clearButton.setOnClickListener(new Button.OnClickListener() {
			public void onClick(View v) {
				textLcdJNI.clear();
			}
		});
	}
	
	@Override
	protected void onResume() {
		textLcdJNI.initialize();
		super.onResume();
	}

	@Override
	protected void onPause() {
		textLcdJNI.off();
		super.onPause();
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

}
