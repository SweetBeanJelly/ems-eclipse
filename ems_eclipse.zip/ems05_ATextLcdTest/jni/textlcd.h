
#define TEXTLCD_H_

#define TEXTLCD_ON	1
#define TEXTLCD_OFF	2
#define TEXTLCD_INIT	3
#define TEXTLCD_CLEAR	4

#define TEXTLCD_LINE1	5
#define TEXTLCD_LINE2	6
