/** Automatically generated file. DO NOT MODIFY */
package com.example.ems_apiezotest;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}