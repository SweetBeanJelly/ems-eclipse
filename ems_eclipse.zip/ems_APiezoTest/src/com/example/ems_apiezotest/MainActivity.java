package com.example.ems_apiezotest;

import com.example.piezojni.PiezoJNI;

import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;

public class MainActivity extends Activity {
	
	private PiezoJNI piezoJNI = new PiezoJNI();
	
	private Button [] scale = new Button[8];

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		this.setResource();
	}
	
	@Override
	protected void onResume() {
		piezoJNI.open();
		super.onResume();
	}
	
	@Override
	protected void onPause() {
		piezoJNI.close();
		super.onPause();
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}
	
	private void setResource() {
		scale[0] = (Button)findViewById(R.id.btn1);
		scale[0].setTag(new int[]{1});
		scale[1] = (Button)findViewById(R.id.btn2);
		scale[1].setTag(new int[]{2});
		scale[2] = (Button)findViewById(R.id.btn3);
		scale[2].setTag(new int[]{3});
		scale[3] = (Button)findViewById(R.id.btn4);
		scale[3].setTag(new int[]{4});
		scale[4] = (Button)findViewById(R.id.btn5);
		scale[4].setTag(new int[]{5});
		scale[5] = (Button)findViewById(R.id.btn6);
		scale[5].setTag(new int[]{6});
		scale[6] = (Button)findViewById(R.id.btn7);
		scale[6].setTag(new int[]{7});
		scale[7] = (Button)findViewById(R.id.btn8);
		scale[7].setTag(new int[]{17});
		
		TouchListener touchListener = new TouchListener();
		for (int i = 0; i < 8; ++i)
			scale[i].setOnTouchListener(touchListener);
	}
	
	public class TouchListener implements Button.OnTouchListener {

		@Override
		public boolean onTouch(View view, MotionEvent motionEvent) {
		Button button = (Button) view;
		int [] tags = (int [])button.getTag();
		
		switch (motionEvent.getAction()) {
			case MotionEvent.ACTION_DOWN:
				piezoJNI.write( (char)tags[0]);
				break;
		
			case MotionEvent.ACTION_UP:
			case MotionEvent.ACTION_MOVE:
				piezoJNI.write( (char)0);
				break;
		}
		
		return true;
		}
		
	}

}
