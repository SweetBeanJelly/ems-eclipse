#include <unistd.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <stdio.h>
#include <fcntl.h>
#include <assert.h>
#include <time.h>
#include <math.h>
#include <ctype.h>
#include "font.h"
#include "textlcd.h"
#define FULL_LED1 9
#define FULL_LED2 8
#define FULL_LED3 7
#define FULL_LED4 6

void ems_DotMatrix(char input[20]) {
		int dev, i, j, offset = 20, ch;
		char result[600], tmp[2];
		dev = open("/dev/ems_dotmatrix", O_WRONLY);
		if (dev != -1) {
			for (j = 0; j < 20; j++)
			result[j] = '0';
			for (i = 0; i < 1; i++) {
				ch = input[i];
				ch -= 0x20;
				for (j = 0; j < 5; j++) {
					sprintf(tmp, "%x%x", font[ch][j] / 16, font[ch][j] % 16);
					result[offset++] = tmp[0];
					result[offset++] = tmp[1];
					}
				result[offset++] = '0';
				result[offset++] = '0';
			}
			for (j = 0; j < 20; j++)
			result[offset++] = '0';
			for (i = 0; i < (offset - 18) / 2; i++) {
				for (j = 0; j < 20; j++) {
					write(dev, &result[2 * i], 20);
				}
			}
		} else {
			printf("Device Open ERROR!\n");
			exit(1);
			}
		close(dev);
}

void ems_FCL(char buf[20]) {
	int fdo;
	char value[3]={0}, value2[3]={0};
	int nums,colnum;
	if ((fdo=open("/dev/ems5_fullColorLed",O_RDWR|O_SYNC)) < 0) {
		perror("/dev/fullcolorled open fail\n");
		exit(1);
	}
	nums = atoi(buf);
	colnum = nums;
	    if (nums > 10) {
	    	colnum = nums%10 + 5 ;
	    }
	    value[0] = colnum*10;     //�÷��� �޾Ƶ��̱� ���� ���� �� ��ȯ
		value[1] = colnum*20;
		value[2] = colnum*30;
		value2[0] = nums;
		value2[1] = nums;
		value2[2] = nums;
		ioctl(fdo,FULL_LED1); write(fdo, value,3); // fullcolorled 4���� ���� ǥ��
		ioctl(fdo,FULL_LED2); write(fdo, value,3);
		ioctl(fdo,FULL_LED3); write(fdo, value,3);
		ioctl(fdo,FULL_LED4); write(fdo, value,3);

		write(fdo, value, 3);
		close(fdo);
}
void delay(clock_t n) {
	clock_t start = clock();
	while (clock() - start < n);}

int main(int argc, char * argv[]) {
	int fd; int fdl; int fds; int fdf; int fdt;
	int i;
	//


	unsigned char check;
	fdf = open("/dev/ems_piezo", O_WRONLY);
	assert(fdf != 0);

	unsigned char ch;
	fdl = open("/dev/fpga_led", O_WRONLY);
	assert(fdl != -1);

	char num[7];
	fds = open("/dev/ems_segment", O_WRONLY);
	assert(fds >= 0);

	fdt = open("/dev/ems5_textLcd", O_WRONLY);
	assert(fdt != -1);

	char buf[20];

	fd=open("/dev/ems_keypad",O_RDWR);
	if(fd < 0) {
		printf("Device Open ERROR!\n");
		return -1;
	}
	printf("push the keypad \n");
	//
	while(1) {
		read(fd,buf,20);
		printf("%s\n",buf);
		switch (buf[0]) {
		case '1':
			ch=1;check=0x11; break;
		case '2':
			ch=2;check=0x12; break;
		case '3':
			ch=4;check=0x13; break;
		case '4':
			ch=8;check=0x14; break;
		case '5':
			ch=16;check=0x15; break;
		case '6':
			ch=32;check=0x16; break;
		case '7':
			ch=64;check=0x17; break;
		case '8':
			ch=128;check=0x21; break;
		}
		//
		write(fdl, &ch, 1);
		write(fdf, &check, 1);
		usleep(100000);
		check=0x00;
		write(fdf, &check, 1);
		//
		sprintf(num,"%06s",buf);
		write(fds,num,6);
		ems_DotMatrix(buf);
		ioctl(fdt, TEXTLCD_INIT);
		ioctl(fdt, TEXTLCD_CLEAR);
		ioctl(fdt, TEXTLCD_LINE1);
		write(fdt, buf, 1);
		ioctl(fdt, TEXTLCD_LINE2);
		write(fdt, "push", 4);
		ems_FCL(buf);
		//
//		delay(300000);
		ch=0;
		write(fdl, &ch, 1);
		//
		ioctl(fdt, TEXTLCD_OFF);
		sleep(1);
		memset(buf,0,sizeof(buf));
	}
//		while(1) {
//			read(fd,buf,20);
//	//		printf("%s %d\r\n",buf, cnt++);
//			printf("%s\n",buf);
//			switch (buf[0]) {
//			case '1':
//				check=0x11; break;
//			case '2':
//				check=0x12; break;
//			case '3':
//				check=0x13; break;
//			case '4':
//				check=0x14; break;
//			case '5':
//				check=0x15; break;
//			case '6':
//				check=0x16; break;
//			case '7':
//				check=0x17; break;
//			case '8':
//				check=0x21; break;
//			}
//			write(fdf, &check, 1);
//			usleep(200000);
//			check=0x00;
//			write(fdf, &check, 1);
//			sleep(1);
//			memset(buf,0,sizeof(buf));
//		}
	close(fd);
	close(fdl);
	close(fdf);
	close(fds);
	close(fdt);
	return 0;
}
